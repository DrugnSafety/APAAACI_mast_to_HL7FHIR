(() => {
  'use strict';
  const panel = document.querySelector('[data-player]');
  if (!panel) return;
  const video = panel.querySelector('video');
  const languageButtons = [...panel.querySelectorAll('[data-lang]')];
  const chapterButtons = [...panel.querySelectorAll('[data-seek]')];
  const title = panel.querySelector('[data-film-title]');
  const description = panel.querySelector('[data-film-description]');
  const download = panel.querySelector('[data-film-download]');
  const chaptersHeading = panel.querySelector('[data-chapter-heading]');
  const film = {
    ko: {
      title: '검사표 한 장이 결과지가 되기까지',
      description: '검사값을 원본과 대조한 뒤 집먼지진드기·고양이·꽃가루 문진을 살펴봅니다. 이어서 환자 결과지, 카드뉴스, FHIR 기록을 확인합니다.',
      chapters: ["검사표 입력", "OCR 대조와 확인", "노출과 증상", "집먼지진드기 문진", "고양이 문진", "꽃가루 문진", "환자 안내문", "교육 카드뉴스", "FHIR 파일"],
      chapterLabel: '장면 선택', download: '한국어 영상 받기', caption: '한국어', mediaLabel: '한국어 과정 영상'
    },
    en: {
      title: 'From a test sheet to a patient report',
      description: 'Follow a synthetic test sheet through OCR review, dust mite, cat and pollen questions, patient education and FHIR export.',
      chapters: ["Source test sheet", "OCR review", "Exposure history", "House dust mite questions", "Cat questions", "Pollen questions", "Patient guidance", "Education cards", "FHIR export"],
      chapterLabel: 'Chapters', download: 'Download English video', caption: 'English', mediaLabel: 'English workflow film'
    }
  };
  const bundledCaptions = {"ko": "data:text/vtt;charset=utf-8;base64,V0VCVlRUCgoxCjAwOjAwOjAwLjAwMCAtLT4gMDA6MDA6MDguMDAwCuqzteqwnCDtlanshLEgTUFTVCDqsoDsgqztkZzsnoXri4jri6QuCuydtCDsgqzroYDsl5DripQgNjnqsJwg7ZWt7JuQ7J20IOyeiOyKteuLiOuLpC4KCjIKMDA6MDA6MDguMDAwIC0tPiAwMDowMDoxNi4wMDAK6rCcIO2RnO2UvOulvCBPQ1LroZwg7J297J2AIOqwkuydgCA3MTTsnoXri4jri6QuCuqygOyCrOyngCDsm5Drs7jsnYAgNy4xNCBJVS9tTCwgM+uTseq4ieyeheuLiOuLpC4KCjMKMDA6MDA6MTYuMDAwIC0tPiAwMDowMDoyNC4wMDAK6rCA7IOB7J2YIOydkeuLteyekOuKlCDqsJzsmYAg7KCR7LSJ7ZWY66m0IOymneyDgeydtCDsi6ztlbTsp5Hri4jri6QuCuyYpOugjOyngOulvCDrqLnsnYAg65Kk7JeQ64qUIOymneyDgeydtCDsl4bri6Tqs6Ag64u17ZaI7Iq164uI64ukLgoKNAowMDowMDoyNC4wMDAgLS0+IDAwOjAwOjMxLjAwMArsp5HrqLzsp4Dsp4Trk5zquLAg66y47KeE7J6F64uI64ukLiDqsIDsg4Eg7J2R64u17J6Q64qUIOyggOuFgSwK7J6Q64qUIOuPmeyViCwg7J2066W4IOyVhOy5qOyXkCDspp3sg4HsnbQg7Ius7ZW07KeE64uk6rOgIOuLte2WiOyKteuLiOuLpC4KCjUKMDA6MDA6MzEuMDAwIC0tPiAwMDowMDozOC4wMDAK6rCA7IOBIOydkeuLteyekOuKlCDsp5HsnYQg66mw7LmgIOu5hOyasOuptArspp3sg4HsnbQg7KKL7JWE7KeE64uk6rOgIOuLte2WiOyKteuLiOuLpC4KCjYKMDA6MDA6MzguMDAwIC0tPiAwMDowMDo0NS4wMDAK7J2067aI7J2064KYIOy5tO2Oq+ydhCDthLjqsbDrgpgg7LKt7IaM7ZWgIOuVjCDspp3sg4HsnbQg7Ius7ZW07KeA64KY7JqUPwrsnbQg66y47ZWt7J2YIOqwgOyDgSDsnZHri7XsnYAg4oCY7JiI4oCZ7J6F64uI64ukLgoKNwowMDowMDo0NS4wMDAgLS0+IDAwOjAwOjUyLjAwMArqs6DslpHsnbQg66y47KeE7J6F64uI64ukLiDqsIDsg4Eg7J2R64u17J6Q64qUIOqzoOyWkeydtOyZgArtlajqu5gg7IK07KeA64qUIOyViuyngOunjCDsnpDso7wg66eM64Kc64uk6rOgIOuLte2WiOyKteuLiOuLpC4KCjgKMDA6MDA6NTIuMDAwIC0tPiAwMDowMDo1OS4wMDAK6rOg7JaR7J2066W8IOyWvOuniOuCmCDsnpDso7wg66eM64KY64KY7JqUPwrqsIDsg4Eg7J2R64u17J6Q64qUIOKAmOyjvCAx7ZqM7K+k4oCZ7J2EIOqzqOuekOyKteuLiOuLpC4KCjkKMDA6MDA6NTkuMDAwIC0tPiAwMDowMTowNi4wMDAK6rOg7JaR7J207JmAIOygkey0ieydtCDripjrqbQg7Kad7IOB7J20IOyLrO2VtOyngOuCmOyalD8K7J20IOusuO2VreydmCDqsIDsg4Eg7J2R64u17J2AIOKAmOyVhOuLiOyYpOKAmeyeheuLiOuLpC4KCjEwCjAwOjAxOjA2LjAwMCAtLT4gMDA6MDE6MTQuMDAwCuymneyDgeydtCDsi6ztlbTsp4DripQg6rOE7KCI7J2EIOusu+yKteuLiOuLpC4K6rCA7IOBIOydkeuLteyekOuKlCDigJjqs4TsoIgg7LCo7J20IOyXhuydjOKAmeydhCDqs6jrnpDsirXri4jri6QuCgoxMQowMDowMToxNC4wMDAgLS0+IDAwOjAxOjIyLjAwMArrtITssqAg64KY66y0IOq9g+qwgOujqCDrrLjtla3snYAgM3417JuU7J2YIOy9lMK364iIIOymneyDgeydhCDrrLvsirXri4jri6QuCuydtCDtlanshLEg7IKs66GA7JeQ64qUIO2VtOuLuSDrrLjtla3snZgg7J2R64u17J20IOyXhuyKteuLiOuLpC4KCjEyCjAwOjAxOjIyLjAwMCAtLT4gMDA6MDE6MzAuMDAwCuyelOuUlCDqvYPqsIDro6gg66y47ZWt7J2AIDV+NuyblCDsnpTrlJTrsK3Ct+2SgOuwrSDqt7zsspjsnZgg7Kad7IOB7J2EIOusu+yKteuLiOuLpC4K7J20IO2VqeyEsSDsgqzroYDsl5DripQg7ZW064u5IOusuO2VreydmCDsnZHri7XsnbQg7JeG7Iq164uI64ukLgoKMTMKMDA6MDE6MzAuMDAwIC0tPiAwMDowMTozOC4wMDAK7J6h7LSIIOq9g+qwgOujqCDrrLjtla3snYAgOH4xMOyblOydmCDsvZTCt+uIiCDspp3sg4HsnYQg66y77Iq164uI64ukLgrsnbQg7ZWp7ISxIOyCrOuhgOyXkOuKlCDtlbTri7kg66y47ZWt7J2YIOydkeuLteydtCDsl4bsirXri4jri6QuCgoxNAowMDowMTozOC4wMDAgLS0+IDAwOjAxOjQ2LjAwMArqsJwg7ZGc7ZS87JmAIOyYpOugjOyngOuKlCDrqqjrkZAgM+uTseq4ieyeheuLiOuLpC4K7ZmY7J6QIOyViOuCtOusuOydgCDqsoDsgqzqsJLqs7wg64W47LacIO2bhCDspp3sg4HsnYQg7ZWo6ruYIOyEpOuqhe2VqeuLiOuLpC4KCjE1CjAwOjAxOjQ2LjAwMCAtLT4gMDA6MDE6NTQuMDAwCuydtCDsgqzroYDroZwg66eM65OgIO2VnOq1reyWtCDsubTrk5zribTsiqQgMTTsnqUg7KSRCuyalOyVvSwg7Kad7IOBIOyXsOq0gOyEsSwg6rCcIO2RnO2UvCDsubTrk5zrpbwg67O07Jes7KSN64uI64ukLgoKMTYKMDA6MDE6NTQuMDAwIC0tPiAwMDowMjowMi4wMDAKRkhJUiBSNCDrsojrk6TsnYAg7ZmY7J6QIDHqsJwsIOqygOyCrCDtla3rqqkgNjnqsJwsCuqygOyCrCDrs7Tqs6DshJwgMeqwnOulvCDsl7DqsrDtlanri4jri6QuIOy0nSA3MeqwnOyeheuLiOuLpC4K", "en": "data:text/vtt;charset=utf-8;base64,V0VCVlRUCgoxCjAwOjAwOjAwLjAwMCAtLT4gMDA6MDA6MDguMDAwClRoaXMgc3ludGhldGljIE1BU1QgYWxsZXJneSB0ZXN0IG1lYXN1cmVzIDY5IGFsbGVyZ2Vucy4KCjIKMDA6MDA6MDguMDAwIC0tPiAwMDowMDoxNi4wMDAKT0NSIHJlYWRzIDcxNCBmb3IgZG9nIGRhbmRlci4KVGhlIHNvdXJjZSBzaG93cyA3LjE0IElVL21MLCBjbGFzcyAzLgoKMwowMDowMDoxNi4wMDAgLS0+IDAwOjAwOjI0LjAwMApUaGUgc2ltdWxhdGVkIHBhdGllbnQgcmVwb3J0cyB3b3JzZSBzeW1wdG9tcyBhZnRlciBkb2cgY29udGFjdAphbmQgbm8gc3ltcHRvbXMgYWZ0ZXIgZWF0aW5nIG9yYW5nZS4KCjQKMDA6MDA6MjQuMDAwIC0tPiAwMDowMDozMS4wMDAKRm9yIGhvdXNlIGR1c3QgbWl0ZXMsIHRoZSBxdWVzdGlvbm5haXJlIGFza3MgYWJvdXQgdGltaW5nLgpUaGUgc2ltdWxhdGVkIGFuc3dlciBpcyB5ZXMgdG8gd29yc2Ugc3ltcHRvbXMgYXQgbmlnaHQgb3IgZWFybHkgbW9ybmluZy4KCjUKMDA6MDA6MzEuMDAwIC0tPiAwMDowMDozOC4wMDAKVGhlIHNpbXVsYXRlZCBwYXRpZW50IHNheXMgc3ltcHRvbXMgaW1wcm92ZQphZnRlciBhIGZldyBkYXlzIGF3YXkgZnJvbSBob21lLgoKNgowMDowMDozOC4wMDAgLS0+IDAwOjAwOjQ1LjAwMApEbyBzeW1wdG9tcyB3b3JzZW4gd2hlbiBzaGFraW5nIG91dCBiZWRkaW5nIG9yIGR1c3Rpbmc/ClRoZSBzaW11bGF0ZWQgYW5zd2VyIGlzIHllcy4KCjcKMDA6MDA6NDUuMDAwIC0tPiAwMDowMDo1Mi4wMDAKVGhlIHNpbXVsYXRlZCBwYXRpZW50IG9mdGVuIHNlZXMgY2F0cwpidXQgZG9lcyBub3QgbGl2ZSB3aXRoIG9uZS4KCjgKMDA6MDA6NTIuMDAwIC0tPiAwMDowMDo1OS4wMDAKSG93IG9mdGVuIGRvZXMgdGhlIHNpbXVsYXRlZCBwYXRpZW50IHNlZSBjYXRzPwpUaGUgYW5zd2VyIGlzIGFib3V0IG9uY2UgYSB3ZWVrLgoKOQowMDowMDo1OS4wMDAgLS0+IDAwOjAxOjA2LjAwMApEbyBzeW1wdG9tcyB3b3JzZW4gd2l0aCBtb3JlIGNhdCBjb250YWN0PwpUaGUgc2ltdWxhdGVkIGFuc3dlciBpcyBuby4KCjEwCjAwOjAxOjA2LjAwMCAtLT4gMDA6MDE6MTQuMDAwClRoZSBzaW11bGF0ZWQgcGF0aWVudCBzZWxlY3RzIOKAnE5vIHNlYXNvbmFsIGRpZmZlcmVuY2XigJ0Kd2hlbiBhc2tlZCB3aGljaCBzZWFzb25zIGFyZSB3b3JzZS4KCjExCjAwOjAxOjE0LjAwMCAtLT4gMDA6MDE6MjIuMDAwClRoZSBzcHJpbmcgdHJlZSBwb2xsZW4gcXVlc3Rpb24gYXNrcyBhYm91dCBub3NlIGFuZCBleWUgc3ltcHRvbXMKZnJvbSBNYXJjaCB0byBNYXkuIFRoaXMgY2FzZSBoYXMgbm8gcmVjb3JkZWQgYW5zd2VyLgoKMTIKMDA6MDE6MjIuMDAwIC0tPiAwMDowMTozMC4wMDAKVGhlIGdyYXNzIHBvbGxlbiBxdWVzdGlvbiBhc2tzIGFib3V0IHN5bXB0b21zIG5lYXIgbGF3bnMKaW4gTWF5IGFuZCBKdW5lLiBUaGlzIGNhc2UgaGFzIG5vIHJlY29yZGVkIGFuc3dlci4KCjEzCjAwOjAxOjMwLjAwMCAtLT4gMDA6MDE6MzguMDAwClRoZSB3ZWVkIHBvbGxlbiBxdWVzdGlvbiBhc2tzIGFib3V0IG5vc2UgYW5kIGV5ZSBzeW1wdG9tcwpmcm9tIEF1Z3VzdCB0byBPY3RvYmVyLiBUaGlzIGNhc2UgaGFzIG5vIHJlY29yZGVkIGFuc3dlci4KCjE0CjAwOjAxOjM4LjAwMCAtLT4gMDA6MDE6NDYuMDAwCkRvZyBkYW5kZXIgYW5kIG9yYW5nZSBhcmUgYm90aCBjbGFzcyAzLiBUaGUgcGF0aWVudCBndWlkYW5jZQpyZWxhdGVzIGVhY2ggdGVzdCByZXN1bHQgdG8gdGhlIHJlcG9ydGVkIHN5bXB0b21zLgoKMTUKMDA6MDE6NDYuMDAwIC0tPiAwMDowMTo1NC4wMDAKVGhlc2UgdGhyZWUgb3JpZ2luYWwgS29yZWFuIGNhcmRzIGNvbWUgZnJvbSB0aGUgMTQtY2FyZCBkZWNrCmdlbmVyYXRlZCBmb3IgdGhlIHN5bnRoZXRpYyBjYXNlLgoKMTYKMDA6MDE6NTQuMDAwIC0tPiAwMDowMjowMi4wMDAKVGhlIEZISVIgUjQgYnVuZGxlIGxpbmtzIG9uZSBQYXRpZW50LCA2OSBPYnNlcnZhdGlvbnMKYW5kIG9uZSBEaWFnbm9zdGljUmVwb3J0LCBmb3IgYSB0b3RhbCBvZiA3MSByZXNvdXJjZXMuCg=="};
  let lang = 'ko';
  let revision = 0;
  function highlightChapter() {
    const time = video.currentTime || 0;
    let current = 0;
    chapterButtons.forEach((button, i) => { if (+button.dataset.seek <= time + 0.12) current = i; });
    chapterButtons.forEach((button, i) => {
      if (i === current) button.setAttribute('aria-current', 'step');
      else button.removeAttribute('aria-current');
    });
  }
  function switchFilm(next, keepTime) {
    if (!film[next] || next === lang) return;
    const id = ++revision;
    const time = keepTime ? video.currentTime || 0 : 0;
    const playing = !video.paused && !video.ended;
    const captionsEnabled = video.textTracks[0]?.mode === 'showing';
    lang = next;
    const f = film[next], base = 'motion/workflow-' + next;
    video.pause();
    video.setAttribute('lang', next);
    video.setAttribute('aria-label', f.mediaLabel);
    video.poster = base + '.jpg';
    video.src = base + '.mp4';
    const track = document.createElement('track');
    Object.assign(track, {kind: 'captions', srclang: next, label: f.caption, src: bundledCaptions[next]});
    video.querySelectorAll('track').forEach(prev => prev.remove());
    video.append(track);
    if (captionsEnabled) track.track.mode = 'showing';
    [title, description, download, chaptersHeading].forEach(el => el.lang = next);
    title.textContent = f.title; description.textContent = f.description;
    chaptersHeading.textContent = f.chapterLabel;
    const transcriptHeading = panel.querySelector('[data-transcript-heading]');
    transcriptHeading.lang = next;
    transcriptHeading.textContent = next === 'en' ? 'Read the transcript' : '영상 대본 읽기';
    panel.querySelectorAll('[data-transcript]').forEach(list => { list.hidden = list.lang !== next; });
    const status = panel.querySelector('[data-film-status]');
    status.lang = next;
    status.textContent = next === 'en' ? 'English film selected.' : '한국어 영상을 선택했습니다.';
    download.href = base + '.mp4'; download.querySelector('span').textContent = f.download;
    languageButtons.forEach(b => b.setAttribute('aria-pressed', String(b.dataset.lang === next)));
    chapterButtons.forEach((b, i) => {
      b.lang = next; b.querySelector('[data-chapter-text]').textContent = f.chapters[i];
    });
    video.addEventListener('loadedmetadata', () => {
      if (id !== revision) return;
      if (time > 0 && Number.isFinite(video.duration)) video.currentTime = Math.min(time, Math.max(0, video.duration - .1));
      if (playing) video.play().catch(() => {});
      highlightChapter();
    }, {once: true});
    video.load();
    highlightChapter();
    const url = new URL(location.href);
    if (next === 'en') url.searchParams.set('film', 'en'); else url.searchParams.delete('film');
    history.replaceState(null, '', url);
  }
  languageButtons.forEach(b => b.addEventListener('click', () => switchFilm(b.dataset.lang, true)));
  chapterButtons.forEach(b => b.addEventListener('click', () => {
    const start = Number(b.dataset.seek);
    const play = () => {
      video.currentTime = start;
      video.play().catch(() => {});
      highlightChapter();
    };
    if (video.readyState) play(); else {
      video.addEventListener('loadedmetadata', play, {once: true}); video.load();
    }
  }));
  video.addEventListener('timeupdate', highlightChapter);
  const initial = new URL(location.href).searchParams.get('film');
  if (initial === 'en') switchFilm('en', false);
  highlightChapter();
})();
