(() => {
  'use strict';
  const panel = document.querySelector('[data-player]');
  if (!panel) return;
  const video = panel.querySelector('video');
  const languageButtons = [...panel.querySelectorAll('[data-lang]')];
  const chapterButtons = [...panel.querySelectorAll('[data-seek]')];
  const title = panel.querySelector('[data-film-title]');
  const description = panel.querySelector('[data-film-description]');
  const download = panel.querySelector('[data-film-download]');
  const chaptersHeading = panel.querySelector('[data-chapter-heading]');
  const film = {
    ko: {
      title: '검사표 한 장이 결과지가 되기까지',
      description: '합성 검사표에서 숫자를 대조하고, 증상 문진을 거쳐 환자 자료와 FHIR 기록을 만드는 과정을 따라갑니다.',
      chapters: ['검사표 입력', 'OCR 대조와 확인', '증상 문진', '환자 결과지', '교육 카드뉴스', 'FHIR 내보내기'],
      chapterLabel: '장면 선택', download: '한국어 영상 받기', caption: '한국어', mediaLabel: '한국어 과정 영상'
    },
    en: {
      title: 'From a test sheet to a patient report',
      description: 'Follow one synthetic test sheet through OCR review, symptom history, patient education and FHIR export.',
      chapters: ['Source test sheet', 'OCR and review', 'Symptom questions', 'Patient report', 'Education cards', 'FHIR export'],
      chapterLabel: 'Chapters', download: 'Download English video', caption: 'English', mediaLabel: 'English workflow film'
    }
  };
  const bundledCaptions = {"ko": "data:text/vtt;charset=utf-8;base64,V0VCVlRUCgoxCjAwOjAwOjAwLjAwMCAtLT4gMDA6MDA6MDguMDAwCu2VqeyEsSBNQVNUIOqygOyCrO2RnOyeheuLiOuLpC4g7J20IOyCrOuhgOyXkOuKlCDtla3sm5AgNjnqsJzqsIAg65Ok7Ja0IOyeiOyKteuLiOuLpC4KCjIKMDA6MDA6MDguMDAwIC0tPiAwMDowMDoxNi4wMDAKT0NSIOybkOusuOyXkOyEnCDqsJwg7ZGc7ZS8IOqwkuydgCA3MTTroZwg7J297ZiU7Iq164uI64ukLiDsm5Drs7jsnZgg6rCS7J2AIDcuMTQgSVUvbUwsIDPrk7HquInsnoXri4jri6QuCgozCjAwOjAwOjE2LjAwMCAtLT4gMDA6MDA6MjQuMDAwCuqwgOyDgeydmCDsnZHri7XsnpDripQg6rCc7JmAIOygkey0ie2VnCDrkqQg7Kad7IOB7J20IOyLrO2VtOyngOyngOunjCwg7Jik66CM7KeA66W8IOuoueqzoCDrgpwg65Kk7JeQ64qUIOymneyDgeydtCDsl4bsl4jri6Tqs6Ag64u17ZaI7Iq164uI64ukLgoKNAowMDowMDoyNC4wMDAgLS0+IDAwOjAwOjMyLjAwMArqsJwg7ZGc7ZS87JmAIOyYpOugjOyngOuKlCDrqqjrkZAgM+uTseq4ieyeheuLiOuLpC4g7ZmY7J6QIOyViOuCtOusuOydgCDqsIEg64W47LacIO2bhOydmCDspp3sg4HsnYQg6rKA7IKs6rCS6rO8IO2VqOq7mCDshKTrqoXtlanri4jri6QuCgo1CjAwOjAwOjMyLjAwMCAtLT4gMDA6MDA6NDAuMDAwCuqzteqwnCDtlanshLEg7IKs66GA7JeQ7IScIOyLpOygnCDsg53shLHrkJwg7ZWc6rWt7Ja0IOy5tOuTnOuJtOyKpOyeheuLiOuLpC4g7LSdIDE07J6lIOykkSDsmpTslb0sIOymneyDgSDsl7DqtIDshLEsIOqwnCDtkZztlLwg7Lm065Oc66W8IOuztOyXrOykjeuLiOuLpC4KCjYKMDA6MDA6NDAuMDAwIC0tPiAwMDowMDo0OC4wMDAK7J20IEZISVIgUjQg67KI65Ok7JeQ64qUIO2ZmOyekCAx6rCcLCDqsoDsgqwg7ZWt66qpIDY56rCcLCDqsoDsgqwg67O06rOg7IScIDHqsJzqsIAg65Ok7Ja0IOyeiOyKteuLiOuLpC4K", "en": "data:text/vtt;charset=utf-8;base64,V0VCVlRUCgoxCjAwOjAwOjAwLjAwMCAtLT4gMDA6MDA6MDguMDAwClRoZSBzeW50aGV0aWMgTUFTVCByZXBvcnQgY29udGFpbnMgNjkgYWxsZXJnZW5zLgoKMgowMDowMDowOC4wMDAgLS0+IDAwOjAwOjE2LjAwMApUaGUgT0NSIG91dHB1dCByZWFkcyA3MTQgZm9yIGRvZyBkYW5kZXIuIENoZWNraW5nIHRoZSBvcmlnaW5hbCByb3cgc2hvd3MgNy4xNCBJVS9tTCwgY2xhc3MgMy4KCjMKMDA6MDA6MTYuMDAwIC0tPiAwMDowMDoyNC4wMDAKVGhlIHNpbXVsYXRlZCBwYXRpZW50IHJlcG9ydHMgd29yc2Ugc3ltcHRvbXMgYWZ0ZXIgZG9nIGNvbnRhY3QgYW5kIG5vIHN5bXB0b21zIGFmdGVyIGVhdGluZyBvcmFuZ2UuCgo0CjAwOjAwOjI0LjAwMCAtLT4gMDA6MDA6MzIuMDAwCkRvZyBkYW5kZXIgYW5kIG9yYW5nZSBhcmUgYm90aCBjbGFzcyAzLiBUaGUgcGF0aWVudCBndWlkYW5jZSBleHBsYWlucyB0aGUgcmVwb3J0ZWQgc3ltcHRvbXMgYWxvbmdzaWRlIGVhY2ggdmFsdWUuCgo1CjAwOjAwOjMyLjAwMCAtLT4gMDA6MDA6NDAuMDAwClRoZXNlIHRocmVlIG9yaWdpbmFsIEtvcmVhbiBjYXJkcyBhcmUgcGFydCBvZiB0aGUgMTQtY2FyZCBkZWNrIGdlbmVyYXRlZCBmb3IgdGhpcyBzeW50aGV0aWMgY2FzZS4KCjYKMDA6MDA6NDAuMDAwIC0tPiAwMDowMDo0OC4wMDAKVGhlIEZISVIgUjQgYnVuZGxlIGxpbmtzIG9uZSBQYXRpZW50LCA2OSBPYnNlcnZhdGlvbnMgYW5kIG9uZSBEaWFnbm9zdGljUmVwb3J0LCBmb3IgYSB0b3RhbCBvZiA3MSByZXNvdXJjZXMuCg=="};
  let lang = 'ko';
  let revision = 0;
  function highlightChapter() {
    const time = video.currentTime || 0;
    let current = 0;
    chapterButtons.forEach((button, i) => { if (+button.dataset.seek <= time + 0.12) current = i; });
    chapterButtons.forEach((button, i) => {
      if (i === current) button.setAttribute('aria-current', 'step');
      else button.removeAttribute('aria-current');
    });
  }
  function switchFilm(next, keepTime) {
    if (!film[next] || next === lang) return;
    const id = ++revision;
    const time = keepTime ? video.currentTime || 0 : 0;
    const playing = !video.paused && !video.ended;
    const captionsEnabled = video.textTracks[0]?.mode === 'showing';
    lang = next;
    const f = film[next], base = 'motion/workflow-' + next;
    video.pause();
    video.setAttribute('lang', next);
    video.setAttribute('aria-label', f.mediaLabel);
    video.poster = base + '.jpg';
    video.src = base + '.mp4';
    const track = document.createElement('track');
    Object.assign(track, {kind: 'captions', srclang: next, label: f.caption, src: bundledCaptions[next]});
    video.querySelectorAll('track').forEach(prev => prev.remove());
    video.append(track);
    if (captionsEnabled) track.track.mode = 'showing';
    [title, description, download, chaptersHeading].forEach(el => el.lang = next);
    title.textContent = f.title; description.textContent = f.description;
    chaptersHeading.textContent = f.chapterLabel;
    const transcriptHeading = panel.querySelector('[data-transcript-heading]');
    transcriptHeading.lang = next;
    transcriptHeading.textContent = next === 'en' ? 'Read the transcript' : '영상 대본 읽기';
    panel.querySelectorAll('[data-transcript]').forEach(list => { list.hidden = list.lang !== next; });
    const status = panel.querySelector('[data-film-status]');
    status.lang = next;
    status.textContent = next === 'en' ? 'English film selected.' : '한국어 영상을 선택했습니다.';
    download.href = base + '.mp4'; download.querySelector('span').textContent = f.download;
    languageButtons.forEach(b => b.setAttribute('aria-pressed', String(b.dataset.lang === next)));
    chapterButtons.forEach((b, i) => {
      b.lang = next; b.querySelector('[data-chapter-text]').textContent = f.chapters[i];
    });
    video.addEventListener('loadedmetadata', () => {
      if (id !== revision) return;
      if (time > 0 && Number.isFinite(video.duration)) video.currentTime = Math.min(time, Math.max(0, video.duration - .1));
      if (playing) video.play().catch(() => {});
      highlightChapter();
    }, {once: true});
    video.load();
    highlightChapter();
    const url = new URL(location.href);
    if (next === 'en') url.searchParams.set('film', 'en'); else url.searchParams.delete('film');
    history.replaceState(null, '', url);
  }
  languageButtons.forEach(b => b.addEventListener('click', () => switchFilm(b.dataset.lang, true)));
  chapterButtons.forEach(b => b.addEventListener('click', () => {
    const start = Number(b.dataset.seek);
    const play = () => {
      video.currentTime = start;
      video.play().catch(() => {});
      highlightChapter();
    };
    if (video.readyState) play(); else {
      video.addEventListener('loadedmetadata', play, {once: true}); video.load();
    }
  }));
  video.addEventListener('timeupdate', highlightChapter);
  const initial = new URL(location.href).searchParams.get('film');
  if (initial === 'en') switchFilm('en', false);
  highlightChapter();
})();
